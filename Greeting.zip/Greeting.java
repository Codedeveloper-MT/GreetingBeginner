	import java.util.Scanner;
	
	public class Greeting{
		public static void main(String [] args){
		
		String name;
		
		Scanner input=new Scanner(System.in);
		
		System.out.println("please enter a name");
		name=input.nextLine();
		
		System.out.println("your name is:"+ name);
		
		/*nextInt();--integer -1,0,1
		nextLine();-- your  name,pen,color,phonenumber,id
		nextDouble();--0.4,8.5,68.5
		next();'a','b','c'*/
		
		 
		
		
		}
	
	
	}